import 'package:google_fonts/google_fonts.dart';
import 'package:flutter/material.dart';


var labelTextS = GoogleFonts.heebo(color: Colors.lightBlue, fontSize: 25);

var numTextS = GoogleFonts.roboto(color: Colors.lightBlue, fontSize: 50);